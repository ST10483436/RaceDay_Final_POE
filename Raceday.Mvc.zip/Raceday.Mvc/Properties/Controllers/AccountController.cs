﻿using Microsoft.AspNetCore.Mvc;
using RaceDay.Services;

namespace RaceDay.Controllers
{// START OF THE NAMESPACE
    public class AccountController : Controller
    {//Start of AccountController Class
        private readonly ApiService _api;
        public AccountController(ApiService api) => _api = api;

        // ==========================================
        // LOGIN
        // ==========================================
        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(string email, string password)
        {// start of the method 
            // Pass 'null' for the body so the API doesn't crash
            var response = await _api.PostAsync($"api/auth/login?email={email}&password={password}", null);

            if (response.IsSuccessStatusCode)
            {// if statements
                var json = await response.Content.ReadAsStringAsync();
                using var doc = System.Text.Json.JsonDocument.Parse(json);

                string role = doc.RootElement.GetProperty("role").GetString()!;
                HttpContext.Session.SetString("UserRole", role);
                HttpContext.Session.SetString("UserEmail", email);

                return RedirectToAction("Index", "Events");
            }//end of if statements

            // Showing the exact error from the API on the screen
            var errorMessage = await response.Content.ReadAsStringAsync();
            ViewBag.Error = $"API Error ({response.StatusCode}): {errorMessage}";

            return View();
        }//end of method

        // ==========================================
        // REGISTER
        // ==========================================
        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(string fullName, string email, string password, string role)
        {// start of register method
            var response = await _api.PostAsync($"api/auth/register?fullName={fullName}&email={email}&password={password}&role={role}&phoneNumber=0123456789&dateOfBirth=1990-01-01", null);

            if (response.IsSuccessStatusCode)
            {// start of if statements
                return RedirectToAction("Login");
            }//end of if statement

            var errorMessage = await response.Content.ReadAsStringAsync();
            ViewBag.Error = $"Registration Failed: {errorMessage}";
            return View();
        }//end of method

        // ==========================================
        // LOGOUT
        // ==========================================
        public IActionResult Logout()
        {//start of Logout Method
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Events");
        }//end of Logout Method
        
    }//end of Account Controller class
}//end of the namespace
