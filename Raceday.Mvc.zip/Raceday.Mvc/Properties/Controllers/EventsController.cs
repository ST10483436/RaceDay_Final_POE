﻿using Microsoft.AspNetCore.Mvc;
using RaceDay.Services;

namespace RaceDay.Controllers
{// start of the namespace
    public class EventsController : Controller
    {// start of EventsController Class
        private readonly ApiService _api;

        public EventsController(ApiService api)
        {
            _api = api;
        }

        // Show all events
        public async Task<IActionResult> Index()
        {// start of Method
            var events = await _api.GetAsync<List<EventViewModel>>("api/events");
            return View(events ?? new List<EventViewModel>());
        }//end of method

        // Show the Create Event form (Organisers only)
        public IActionResult Create()
        {// start of Create method
            if (HttpContext.Session.GetString("UserRole") != "Organiser")
                return RedirectToAction("Login", "Account");

            return View();
        }//end of create method

        // Handle the form submission
        [HttpPost]
        public async Task<IActionResult> Create(string name, string description, DateTime date, string location, decimal distance, string eventType)
        {// start of create method
            if (HttpContext.Session.GetString("UserRole") != "Organiser")
                return RedirectToAction("Login", "Account");

            // Added ', null' at the end so the ApiService doesn't crash
            var response = await _api.PostAsync($"api/events?name={name}&description={description}&date={date:yyyy-MM-dd}&location={location}&distance={distance}&eventType={eventType}", null);

            if (response.IsSuccessStatusCode)
                return RedirectToAction("Index");

            // Show the exact API error if it fails again
            var errorText = await response.Content.ReadAsStringAsync();
            ViewBag.Error = $"Failed to create event. API says: {errorText}";

            return View();
        }//end of method
    }//end of class

    // ViewModel to receive API data
    public class EventViewModel
    {// start of EventViewModel class
        public int EventId { get; set; }
        public string EventName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public DateTime EventDate { get; set; }
        public string Location { get; set; } = string.Empty;
        public decimal Distance { get; set; }
        public string EventType { get; set; } = string.Empty;
        public string? ImageUrl { get; set; }
    }//end of EventViewModel class
}//end of the namespace

